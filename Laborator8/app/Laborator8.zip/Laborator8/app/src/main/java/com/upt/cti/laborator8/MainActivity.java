package com.upt.cti.laborator8;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.view.View;
import android.widget.ArrayAdapter;
import android.widget.ListView;

import com.google.firebase.database.DatabaseReference;

import java.util.ArrayList;
import java.util.List;

public class MainActivity extends AppCompatActivity {
    private DatabaseReference databaseReference;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        List<String> payments = new ArrayList<String>();
        payments.add("45.25");
        payments.add("5.50");
        payments.add("15.60");

        ListView listPayments = (ListView) findViewById(R.id.listPayments);

        ArrayAdapter<String> listAdapter = new ArrayAdapter<String>(this, android.R.layout.simple_list_item_1, payments);

        listPayments.setAdapter(listAdapter);

        payments.add("10.25");
        payments.remove(2);
        listAdapter.notifyDataSetChanged();

    }

    public void clicked(View view) {
    }
}